#ifndef _TRES_RAYA_H_

  #define _TRES_RAYA_H_
  #include <stdio.h>

  void tresRaya();

  static void generarPantalla();
  static void felicitaciones();
  static int menuInicio();
  static void mostrarTablero();
  static int registrarJugada();
  static int verificarSiHayGanador();

#endif
